@echo off
setlocal
where gradle >nul 2>nul
if %errorlevel%==0 (
  gradle -p "%~dp0" %*
  exit /b %errorlevel%
)
echo Gradle 8.9 belum terpasang. Buka folder ini dengan Android Studio untuk Gradle Sync,
echo atau install Gradle 8.9 lalu jalankan gradle :app:assembleDebug.
exit /b 1

package com.lucent.music;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.ClipData;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Random;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public class MainActivity extends Activity {
    private static final int PICK_AUDIO = 410;
    private static final String PREFS = "lucent_store";
    private static final int BG = Color.rgb(16, 11, 25);
    private static final int SURFACE = Color.rgb(27, 19, 40);
    private static final int SURFACE_2 = Color.rgb(38, 27, 55);
    private static final int PURPLE = Color.rgb(184, 140, 255);
    private static final int LAVENDER = Color.rgb(224, 207, 255);
    private static final int TEXT = Color.rgb(247, 242, 252);
    private static final int MUTED = Color.rgb(173, 162, 188);
    private static final int LINE = Color.rgb(59, 44, 77);

    private LinearLayout root;
    private FrameLayout contentFrame;
    private String page = "home";
    private String libraryTab = "Lagu";
    private String query = "";
    private final List<Song> songs = new ArrayList<>();
    private final List<String> playlists = new ArrayList<>();
    private final Map<String, Set<String>> playlistTracks = new HashMap<>();
    private String activePlaylist = "";
    private boolean shuffleEnabled = false;
    private boolean repeatOne = false;
    private final Set<String> liked = new HashSet<>();
    private int currentIndex = -1;
    private boolean playing = false;
    private boolean serviceHasTrack = false;
    private int duration = 0;
    private int position = 0;
    private boolean receiverRegistered = false;
    private BroadcastReceiver receiver;
    private SharedPreferences prefs;

    private static class Song {
        String uri, title, artist, album;
        int duration;
        Song(String uri, String title, String artist, String album, int duration) {
            this.uri = uri; this.title = title; this.artist = artist; this.album = album; this.duration = duration;
        }
        String key() { return uri; }
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        if (Build.VERSION.SDK_INT >= 29) getWindow().setNavigationBarContrastEnforced(false);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        loadSaved();
        receiver = new BroadcastReceiver() {
            @Override public void onReceive(Context context, Intent intent) {
                String action = intent.getAction();
                if (PlaybackService.ACTION_STATE.equals(action)) {
                    playing = intent.getBooleanExtra(PlaybackService.EXTRA_PLAYING, false);
                    serviceHasTrack = intent.getBooleanExtra(PlaybackService.EXTRA_READY, false);
                    duration = intent.getIntExtra(PlaybackService.EXTRA_DURATION, duration);
                    position = intent.getIntExtra(PlaybackService.EXTRA_POSITION, position);
                    refreshPlayerChrome();
                } else if (PlaybackService.ACTION_NEXT_REQUEST.equals(action)) {
                    nextSong();
                } else if (PlaybackService.ACTION_PREV_REQUEST.equals(action)) {
                    previousSong();
                }
            }
        };
        IntentFilter f = new IntentFilter();
        f.addAction(PlaybackService.ACTION_STATE);
        f.addAction(PlaybackService.ACTION_NEXT_REQUEST);
        f.addAction(PlaybackService.ACTION_PREV_REQUEST);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(receiver, f, Context.RECEIVER_NOT_EXPORTED);
        else registerReceiver(receiver, f);
        receiverRegistered = true;
        buildShell();
        renderPage();
    }

    @Override protected void onStop() { super.onStop(); }

    @Override protected void onDestroy() {
        if (receiverRegistered) { unregisterReceiver(receiver); receiverRegistered = false; }
        super.onDestroy();
    }

    private void buildShell() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        setContentView(root);
        contentFrame = new FrameLayout(this);
        root.addView(contentFrame, new LinearLayout.LayoutParams(-1, 0, 1));
    }

    private void renderPage() {
        contentFrame.removeAllViews();
        View pageView;
        switch (page) {
            case "search": pageView = searchPage(); break;
            case "library": pageView = libraryPage(); break;
            case "playlist": pageView = playlistPage(); break;
            case "settings": pageView = settingsPage(); break;
            case "now": pageView = nowPlayingPage(); break;
            default: pageView = homePage(); break;
        }
        contentFrame.addView(pageView, new FrameLayout.LayoutParams(-1, -1));
        rebuildBottomChrome();
    }

    private void rebuildBottomChrome() {
        int old = root.getChildCount();
        while (root.getChildCount() > 1) root.removeViewAt(1);
        if (currentIndex >= 0 && currentIndex < songs.size() && !"now".equals(page)) {
            root.addView(miniPlayer(), new LinearLayout.LayoutParams(-1, dp(76)));
        }
        root.addView(bottomNav(), new LinearLayout.LayoutParams(-1, dp(66)));
    }

    private View bottomNav() {
        LinearLayout nav = new LinearLayout(this);
        nav.setGravity(Gravity.CENTER);
        nav.setPadding(dp(12), dp(6), dp(12), dp(8));
        nav.setBackgroundColor(BG);
        String[] labels = {"⌂\nBeranda", "⌕\nCari", "▤\nPustaka"};
        String[] keys = {"home", "search", "library"};
        for (int i = 0; i < labels.length; i++) {
            final String key = keys[i];
            TextView item = text(labels[i], 12, page.equals(key) ? PURPLE : MUTED, true);
            item.setGravity(Gravity.CENTER);
            item.setPadding(dp(8), dp(7), dp(8), dp(7));
            if (page.equals(key)) item.setBackground(round(SURFACE_2, 22, PURPLE, 1));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -1, 1);
            lp.setMargins(dp(5), 0, dp(5), 0);
            nav.addView(item, lp);
            item.setOnClickListener(v -> { page = key; renderPage(); });
        }
        return nav;
    }

    private View miniPlayer() {
        Song s = songs.get(currentIndex);
        LinearLayout wrap = new LinearLayout(this);
        wrap.setGravity(Gravity.CENTER_VERTICAL);
        wrap.setPadding(dp(12), dp(8), dp(10), dp(8));
        wrap.setBackground(round(SURFACE_2, 18, LINE, 1));
        LinearLayout.LayoutParams outer = new LinearLayout.LayoutParams(-1, -1);
        outer.setMargins(dp(12), dp(4), dp(12), dp(5));
        wrap.setLayoutParams(outer);

        TextView art = artwork(46);
        wrap.addView(art, new LinearLayout.LayoutParams(dp(46), dp(46)));
        LinearLayout info = new LinearLayout(this);
        info.setOrientation(LinearLayout.VERTICAL);
        info.setGravity(Gravity.CENTER_VERTICAL);
        info.setPadding(dp(10), 0, dp(4), 0);
        info.addView(text(s.title, 13, TEXT, true), new LinearLayout.LayoutParams(-1, -2));
        info.addView(text(s.artist, 11, MUTED, false));
        wrap.addView(info, new LinearLayout.LayoutParams(0, -1, 1));
        TextView like = text(liked.contains(s.key()) ? "♥" : "♡", 23, liked.contains(s.key()) ? PURPLE : MUTED, true);
        like.setGravity(Gravity.CENTER);
        wrap.addView(like, new LinearLayout.LayoutParams(dp(36), -1));
        like.setOnClickListener(v -> toggleLike(s));
        TextView play = text(playing ? "Ⅱ" : "▶", 18, BG, true);
        play.setGravity(Gravity.CENTER);
        play.setBackground(round(PURPLE, 16, PURPLE, 1));
        wrap.addView(play, new LinearLayout.LayoutParams(dp(42), dp(42)));
        play.setOnClickListener(v -> togglePlayback());
        TextView next = text("▸|", 17, LAVENDER, true);
        next.setGravity(Gravity.CENTER);
        wrap.addView(next, new LinearLayout.LayoutParams(dp(36), -1));
        next.setOnClickListener(v -> nextSong());
        wrap.setOnClickListener(v -> { page = "now"; renderPage(); });
        return wrap;
    }

    private View homePage() {
        LinearLayout body = pageColumn();
        addTopBar(body, "Lucent", true);
        TextView greeting = text("Selamat malam", 28, TEXT, true);
        greeting.setTypeface(Typeface.SERIF, Typeface.BOLD);
        body.addView(greeting);
        body.addView(text("Temukan ritme yang terasa seperti kamu.", 13, MUTED, false));
        space(body, 18);

        if (!songs.isEmpty()) {
            section(body, "Lanjutkan mendengarkan", "LIHAT SEMUA", () -> { page = "library"; renderPage(); });
            LinearLayout recent = new LinearLayout(this);
            recent.setOrientation(LinearLayout.HORIZONTAL);
            for (int i = Math.max(0, songs.size() - 2); i < songs.size(); i++) {
                final int index = i;
                Song s = songs.get(i);
                LinearLayout tile = new LinearLayout(this);
                tile.setGravity(Gravity.CENTER_VERTICAL);
                tile.setPadding(dp(8), dp(8), dp(8), dp(8));
                tile.setBackground(round(SURFACE, 14, LINE, 1));
                tile.addView(artwork(48), new LinearLayout.LayoutParams(dp(48), dp(48)));
                TextView name = text(s.title, 12, TEXT, true);
                name.setMaxLines(2);
                name.setPadding(dp(8), 0, 0, 0);
                tile.addView(name, new LinearLayout.LayoutParams(0, -2, 1));
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(66), 1);
                lp.setMargins(0, 0, dp(7), 0);
                recent.addView(tile, lp);
                tile.setOnClickListener(v -> playSong(index));
            }
            body.addView(recent);
        } else {
            LinearLayout hero = card(SURFACE_2);
            TextView orb = text("♫", 42, LAVENDER, true);
            orb.setGravity(Gravity.CENTER);
            hero.addView(orb, new LinearLayout.LayoutParams(-1, dp(74)));
            hero.addView(text("Musikmu, ruangmu.", 19, TEXT, true));
            hero.addView(text("Tambahkan lagu dari perangkat untuk mulai membangun pustaka Lucent.", 13, MUTED, false));
            TextView add = action("＋  Tambahkan musik", true);
            LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(-1, dp(46)); ap.topMargin = dp(14);
            hero.addView(add, ap);
            add.setOnClickListener(v -> pickAudio());
            body.addView(hero);
        }

        space(body, 18);
        LinearLayout streak = card(SURFACE);
        LinearLayout streakRow = row();
        TextView flame = text("✦", 30, PURPLE, true);
        streakRow.addView(flame, new LinearLayout.LayoutParams(dp(50), dp(48)));
        LinearLayout streakInfo = column();
        streakInfo.addView(text("Bangun streak mendengarkan", 15, TEXT, true));
        streakInfo.addView(text("Putar satu lagu setiap hari dan jaga ritmemu.", 12, MUTED, false));
        streakRow.addView(streakInfo, new LinearLayout.LayoutParams(0, -2, 1));
        streak.addView(streakRow);
        body.addView(streak);

        space(body, 18);
        section(body, "Mood hari ini", "", null);
        HorizontalScrollView moods = new HorizontalScrollView(this);
        moods.setHorizontalScrollBarEnabled(false);
        LinearLayout moodRow = row();
        String[] mood = {"✦  Feel good", "☾  Relax", "↗  Energize", "⌁  Focus", "♡  Romance"};
        for (String m : mood) {
            TextView chip = text(m, 12, LAVENDER, true);
            chip.setPadding(dp(14), dp(10), dp(14), dp(10));
            chip.setBackground(round(SURFACE_2, 24, LINE, 1));
            LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-2, -2); cp.setMargins(0, 0, dp(8), 0);
            moodRow.addView(chip, cp);
            chip.setOnClickListener(v -> Toast.makeText(this, "Mood " + m.replaceAll("^[^ ]+  ", "") + " dipilih", Toast.LENGTH_SHORT).show());
        }
        moods.addView(moodRow);
        body.addView(moods);

        space(body, 18);
        section(body, "Speed dial", "JELAJAHI", () -> { page = "search"; renderPage(); });
        String[] quick = {"Terakhir diputar", "Disukai", "Album pilihan", "Lagu santai", "Artis favorit", "Semua musik"};
        String[] symbols = {"◷", "♡", "▣", "☾", "♬", "♫"};
        for (int start = 0; start < quick.length; start += 2) {
            LinearLayout r = row();
            for (int j = start; j < Math.min(start + 2, quick.length); j++) {
                final int idx = j;
                LinearLayout tile = card(SURFACE);
                tile.setOrientation(LinearLayout.HORIZONTAL);
                tile.setGravity(Gravity.CENTER_VERTICAL);
                TextView icon = text(symbols[j], 26, PURPLE, true);
                icon.setGravity(Gravity.CENTER);
                tile.addView(icon, new LinearLayout.LayoutParams(dp(42), dp(42)));
                TextView label = text(quick[j], 13, TEXT, true);
                label.setPadding(dp(8), 0, 0, 0);
                tile.addView(label, new LinearLayout.LayoutParams(0, -2, 1));
                LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(0, dp(70), 1);
                tp.setMargins(0, 0, dp(8), dp(8));
                r.addView(tile, tp);
                tile.setOnClickListener(v -> {
                    if (idx == 1) { libraryTab = "Disukai"; page = "library"; }
                    else if (idx == 5) { libraryTab = "Lagu"; page = "library"; }
                    else page = "search";
                    renderPage();
                });
            }
            body.addView(r);
        }
        if (!songs.isEmpty()) {
            space(body, 12);
            section(body, "Baru ditambahkan", "PUSTAKA", () -> { page = "library"; renderPage(); });
            for (int i = songs.size() - 1; i >= Math.max(0, songs.size() - 4); i--) addSongRow(body, i, true);
        }
        return scroll(body);
    }

    private View searchPage() {
        LinearLayout body = pageColumn();
        addTopBar(body, "Cari", true);
        EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setTextColor(TEXT);
        input.setHintTextColor(MUTED);
        input.setTextSize(14);
        input.setHint("Cari lagu, album, artis...");
        input.setPadding(dp(15), 0, dp(15), 0);
        input.setBackground(round(SURFACE_2, 16, LINE, 1));
        input.setText(query);
        body.addView(input, new LinearLayout.LayoutParams(-1, dp(50)));
        LinearLayout results = column();
        body.addView(results);
        Runnable fill = () -> {
            results.removeAllViews();
            String q = query.toLowerCase(Locale.ROOT).trim();
            if (q.isEmpty()) {
                section(results, "Terakhir diputar", "", null);
                if (songs.isEmpty()) results.addView(text("Riwayat lagu akan muncul di sini setelah kamu memutar audio.", 13, MUTED, false));
                else for (int i = songs.size() - 1; i >= Math.max(0, songs.size() - 5); i--) addSongRow(results, i, false);
                space(results, 12);
                section(results, "Jelajahi", "", null);
                String[] genres = {"Pop", "Indie", "R&B", "Elektronik", "Akustik", "Jazz"};
                for (int i = 0; i < genres.length; i += 3) {
                    LinearLayout r = row();
                    for (int j = i; j < Math.min(i + 3, genres.length); j++) {
                        TextView chip = text(genres[j], 12, LAVENDER, true);
                        chip.setGravity(Gravity.CENTER);
                        chip.setBackground(round(SURFACE, 12, LINE, 1));
                        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(48), 1); lp.setMargins(0, 0, dp(7), dp(7));
                        r.addView(chip, lp);
                    }
                    results.addView(r);
                }
            } else {
                section(results, "Hasil di perangkat", "", null);
                int count = 0;
                for (int i = 0; i < songs.size(); i++) {
                    Song s = songs.get(i);
                    if ((s.title + " " + s.artist + " " + s.album).toLowerCase(Locale.ROOT).contains(q)) { addSongRow(results, i, false); count++; }
                }
                if (count == 0) results.addView(text("Tidak ada hasil lokal untuk “" + query + "”. Tambahkan file audio dari perangkat atau coba kata lain.", 13, MUTED, false));
            }
        };
        fill.run();
        input.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int st, int c, int a) { }
            @Override public void onTextChanged(CharSequence s, int st, int before, int count) { query = s.toString(); fill.run(); }
            @Override public void afterTextChanged(Editable e) { }
        });
        return scroll(body);
    }

    private View libraryPage() {
        LinearLayout body = pageColumn();
        addTopBar(body, "Pustaka", true);
        HorizontalScrollView tabs = new HorizontalScrollView(this);
        tabs.setHorizontalScrollBarEnabled(false);
        LinearLayout tabRow = row();
        String[] names = {"Playlist", "Lagu", "Album", "Artis", "Podcast", "Disukai", "Diunduh", "Diunggah"};
        for (String name : names) {
            TextView tab = text(name, 12, libraryTab.equals(name) ? BG : MUTED, true);
            tab.setGravity(Gravity.CENTER);
            tab.setPadding(dp(15), dp(9), dp(15), dp(9));
            tab.setBackground(round(libraryTab.equals(name) ? PURPLE : SURFACE, 20, libraryTab.equals(name) ? PURPLE : LINE, 1));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, dp(38)); lp.setMargins(0, 0, dp(7), 0);
            tabRow.addView(tab, lp);
            tab.setOnClickListener(v -> { libraryTab = name; renderPage(); });
        }
        tabs.addView(tabRow);
        body.addView(tabs);
        space(body, 18);
        LinearLayout head = row();
        head.addView(text(libraryTab.equals("Lagu") ? "Semua lagu" : libraryTab, 20, TEXT, true), new LinearLayout.LayoutParams(0, -2, 1));
        TextView add = action("＋", true);
        head.addView(add, new LinearLayout.LayoutParams(dp(44), dp(42)));
        add.setOnClickListener(v -> {
            if (libraryTab.equals("Playlist")) createPlaylist(); else pickAudio();
        });
        body.addView(head);
        body.addView(text(libraryTab.equals("Lagu") ? songs.size() + " lagu di perangkat" : "Koleksi Lucent", 12, MUTED, false));
        space(body, 12);

        if (libraryTab.equals("Playlist")) {
            if (playlists.isEmpty()) {
                LinearLayout empty = card(SURFACE);
                empty.addView(text("Belum ada playlist", 16, TEXT, true));
                empty.addView(text("Buat playlist untuk mengelompokkan lagu sesuai suasana.", 13, MUTED, false));
                TextView create = action("＋  Buat playlist", true);
                LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, dp(44)); cp.topMargin = dp(12); empty.addView(create, cp);
                create.setOnClickListener(v -> createPlaylist());
                body.addView(empty);
            } else {
                for (String p : playlists) {
                    LinearLayout r = row(); r.setPadding(dp(12), dp(12), dp(12), dp(12)); r.setBackground(round(SURFACE, 14, LINE, 1));
                    r.addView(artwork(48), new LinearLayout.LayoutParams(dp(48), dp(48)));
                    LinearLayout info = column(); info.setPadding(dp(12), 0, 0, 0);
                    info.addView(text(p, 14, TEXT, true)); info.addView(text("Playlist pribadi", 12, MUTED, false));
                    r.addView(info, new LinearLayout.LayoutParams(0, -2, 1));
                    body.addView(r); space(body, 7);
                    r.setOnClickListener(v -> { activePlaylist = p; page = "playlist"; renderPage(); });
                }
            }
        } else if (libraryTab.equals("Disukai")) {
            int count = 0;
            for (int i = 0; i < songs.size(); i++) if (liked.contains(songs.get(i).key())) { addSongRow(body, i, true); count++; }
            if (count == 0) body.addView(emptyText("Lagu yang kamu sukai akan muncul di sini."));
        } else if (libraryTab.equals("Diunduh")) {
            body.addView(emptyText("Belum ada unduhan. Lucent saat ini memutar file lokal yang kamu pilih sendiri."));
        } else if (libraryTab.equals("Diunggah")) {
            body.addView(emptyText("Belum ada file yang diunggah ke layanan cloud."));
        } else if (libraryTab.equals("Album")) {
            LinkedHashMap<String, List<Integer>> groups = new LinkedHashMap<>();
            for (int i = 0; i < songs.size(); i++) {
                String album = songs.get(i).album == null || songs.get(i).album.trim().isEmpty() ? "Album tidak diketahui" : songs.get(i).album;
                if (!groups.containsKey(album)) groups.put(album, new ArrayList<>());
                groups.get(album).add(i);
            }
            if (groups.isEmpty()) body.addView(emptyText("Album akan muncul setelah kamu menambahkan audio dengan metadata album."));
            for (Map.Entry<String, List<Integer>> entry : groups.entrySet()) {
                LinearLayout group = row(); group.setGravity(Gravity.CENTER_VERTICAL); group.setPadding(dp(10), dp(9), dp(10), dp(9)); group.setBackground(round(SURFACE, 14, LINE, 1));
                group.addView(artwork(48), new LinearLayout.LayoutParams(dp(48), dp(48)));
                LinearLayout meta = column(); meta.setPadding(dp(11), 0, 0, 0);
                meta.addView(text(entry.getKey(), 14, TEXT, true));
                meta.addView(text(entry.getValue().size() + " lagu • " + songs.get(entry.getValue().get(0)).artist, 12, MUTED, false));
                group.addView(meta, new LinearLayout.LayoutParams(0, -2, 1));
                body.addView(group); space(body, 7);
                group.setOnClickListener(v -> showCollectionSongs(entry.getKey(), entry.getValue()));
            }
        } else if (libraryTab.equals("Artis")) {
            LinkedHashMap<String, List<Integer>> groups = new LinkedHashMap<>();
            for (int i = 0; i < songs.size(); i++) {
                String artist = songs.get(i).artist == null || songs.get(i).artist.trim().isEmpty() ? "Artis tidak diketahui" : songs.get(i).artist;
                if (!groups.containsKey(artist)) groups.put(artist, new ArrayList<>());
                groups.get(artist).add(i);
            }
            if (groups.isEmpty()) body.addView(emptyText("Artis akan muncul setelah kamu menambahkan audio dengan metadata artis."));
            for (Map.Entry<String, List<Integer>> entry : groups.entrySet()) {
                LinearLayout group = row(); group.setGravity(Gravity.CENTER_VERTICAL); group.setPadding(dp(10), dp(9), dp(10), dp(9)); group.setBackground(round(SURFACE, 14, LINE, 1));
                TextView avatar = text("♫", 22, LAVENDER, true); avatar.setGravity(Gravity.CENTER); avatar.setBackground(round(SURFACE_2, 30, LINE, 1));
                group.addView(avatar, new LinearLayout.LayoutParams(dp(48), dp(48)));
                LinearLayout meta = column(); meta.setPadding(dp(11), 0, 0, 0);
                meta.addView(text(entry.getKey(), 14, TEXT, true));
                meta.addView(text(entry.getValue().size() + " lagu", 12, MUTED, false));
                group.addView(meta, new LinearLayout.LayoutParams(0, -2, 1));
                body.addView(group); space(body, 7);
                group.setOnClickListener(v -> showCollectionSongs(entry.getKey(), entry.getValue()));
            }
        } else if (libraryTab.equals("Podcast")) {
            body.addView(emptyText("Belum ada podcast lokal. Kamu tetap bisa menambahkan file audio melalui tab Lagu."));
        } else {
            if (songs.isEmpty()) body.addView(emptyText("Pustakamu masih kosong. Tambahkan file audio untuk mulai mendengarkan."));
            else for (int i = 0; i < songs.size(); i++) addSongRow(body, i, true);
        }
        return scroll(body);
    }


    private void showCollectionSongs(String title, List<Integer> indices) {
        LinearLayout content = column(); content.setPadding(dp(18), dp(8), dp(18), dp(8));
        for (int index : indices) addSongRow(content, index, true);
        ScrollView scroller = scroll(content);
        new AlertDialog.Builder(this).setTitle(title).setView(scroller).setPositiveButton("Tutup", null).show();
    }

    private View playlistPage() {
        LinearLayout body = pageColumn();
        LinearLayout bar = row();
        TextView back = text("‹", 30, TEXT, true); back.setGravity(Gravity.CENTER);
        bar.addView(back, new LinearLayout.LayoutParams(dp(42), dp(44)));
        back.setOnClickListener(v -> { page = "library"; libraryTab = "Playlist"; renderPage(); });
        TextView title = text(activePlaylist, 22, TEXT, true); title.setTypeface(Typeface.SERIF, Typeface.BOLD);
        bar.addView(title, new LinearLayout.LayoutParams(0, dp(44), 1));
        TextView add = action("＋", true); bar.addView(add, new LinearLayout.LayoutParams(dp(44), dp(42)));
        add.setOnClickListener(v -> addTracksToPlaylist(activePlaylist));
        body.addView(bar);
        Set<String> members = playlistTracks.getOrDefault(activePlaylist, new HashSet<>());
        body.addView(text(members.size() + " lagu", 12, MUTED, false));
        space(body, 12);
        int count = 0;
        for (int i = 0; i < songs.size(); i++) {
            if (members.contains(songs.get(i).key())) { addSongRow(body, i, true); count++; }
        }
        if (count == 0) body.addView(emptyText("Playlist ini masih kosong. Ketuk + untuk menambahkan lagu dari pustaka."));
        return scroll(body);
    }

    private void addTracksToPlaylist(String playlist) {
        if (songs.isEmpty()) { Toast.makeText(this, "Tambahkan audio terlebih dahulu", Toast.LENGTH_SHORT).show(); return; }
        String[] choices = new String[songs.size()];
        for (int i = 0; i < songs.size(); i++) choices[i] = songs.get(i).title + " — " + songs.get(i).artist;
        boolean[] checked = new boolean[songs.size()];
        Set<String> existing = playlistTracks.getOrDefault(playlist, new HashSet<>());
        for (int i = 0; i < songs.size(); i++) checked[i] = existing.contains(songs.get(i).key());
        new AlertDialog.Builder(this).setTitle("Pilih lagu")
                .setMultiChoiceItems(choices, checked, (dialog, which, isChecked) -> checked[which] = isChecked)
                .setNegativeButton("Batal", null)
                .setPositiveButton("Simpan", (dialog, which) -> {
                    Set<String> selected = new HashSet<>();
                    for (int i = 0; i < songs.size(); i++) if (checked[i]) selected.add(songs.get(i).key());
                    playlistTracks.put(playlist, selected); savePlaylists(); renderPage();
                }).show();
    }

    private void showSongMenu(int index) {
        if (index < 0 || index >= songs.size()) return;
        Song song = songs.get(index);
        List<String> actions = new ArrayList<>();
        if ("playlist".equals(page)) actions.add("Hapus dari playlist");
        actions.add("Tambahkan ke playlist");
        actions.add(liked.contains(song.key()) ? "Hapus dari Disukai" : "Tambahkan ke Disukai");
        String[] items = actions.toArray(new String[0]);
        new AlertDialog.Builder(this).setTitle(song.title).setItems(items, (dialog, which) -> {
            String action = items[which];
            if (action.equals("Hapus dari playlist")) {
                Set<String> set = playlistTracks.get(activePlaylist); if (set != null) set.remove(song.key()); savePlaylists(); renderPage();
            } else if (action.equals("Tambahkan ke playlist")) {
                if (playlists.isEmpty()) { createPlaylist(); return; }
                String[] names = playlists.toArray(new String[0]);
                new AlertDialog.Builder(this).setTitle("Pilih playlist").setItems(names, (d, p) -> {
                    Set<String> set = playlistTracks.computeIfAbsent(names[p], k -> new HashSet<>());
                    set.add(song.key()); savePlaylists(); Toast.makeText(this, "Ditambahkan ke " + names[p], Toast.LENGTH_SHORT).show();
                }).show();
            } else toggleLike(song);
        }).show();
    }

    private View settingsPage() {
        LinearLayout body = pageColumn();
        addTopBar(body, "Pengaturan", false);
        section(body, "Antarmuka", "", null);
        settingCard(body, "Tampilan", "Tema utama Dark Purple • Lavender", "◉", () -> showThemeInfo());
        settingCard(body, "Preset tampilan", prefs.getString("preset", "Minimalis") + " • Dark Purple", "✧", () -> showPresetDialog());
        settingCard(body, "Gaya ikon aplikasi", "Gaya ikon Lucent", "✥", () -> showInfo("Gaya ikon", "Ikon aplikasi Lucent menggunakan identitas ungu. Penggantian ikon launcher belum tersedia pada versi awal."));
        settingToggle(body, "Animasi halus", "Transisi dan respons tombol", true);
        settingToggle(body, "Streak di Beranda", "Tampilkan progres kebiasaan mendengarkan", true);
        settingToggle(body, "Tema dinamis", "Gunakan aksen lavender Lucent", true);
        settingToggle(body, "Warna ikon dinamis", "Gunakan warna ikon bernuansa ungu", true);
        settingToggle(body, "Refresh rate tinggi", "Ikuti kemampuan layar perangkat", false);
        settingToggle(body, "Skala landscape", "Tata letak lebih lebar saat horizontal", false);
        space(body, 14);
        section(body, "Dynamic Island", "", null);
        settingToggle(body, "Pratinjau Now Playing", "Tampilkan kapsul pemutar di dalam Lucent", true);
        body.addView(dynamicIslandPreview());
        settingCard(body, "Izin tampil di atas aplikasi lain", "Tidak diminta pada versi awal", "▱", () -> showInfo("Overlay", "Lucent belum meminta izin overlay sistem. Kontrol pemutar tetap tersedia di dalam aplikasi dan notifikasi pemutaran."));
        space(body, 14);
        section(body, "Pemutar & Konten", "", null);
        settingCard(body, "Pemutar dan audio", "File lokal • kontrol media Android", "▶", () -> showInfo("Pemutar dan audio", "Lucent menggunakan pemutar Android untuk file audio yang kamu pilih. Pemutaran latar didukung melalui layanan media."));
        settingCard(body, "Konten", "Preferensi pustaka lokal", "文", () -> showInfo("Konten", "Versi awal berfokus pada audio lokal. Katalog streaming belum terhubung."));
        settingCard(body, "Terjemahan lirik AI", "Belum tersedia • perlu layanan API", "文", () -> showInfo("Lirik AI", "Fitur ini belum aktif karena belum ada backend atau penyedia lirik/AI yang dikonfigurasi."));
        settingCard(body, "Android Auto", "Dukungan khusus belum diaktifkan", "⌁", () -> showInfo("Android Auto", "Integrasi Android Auto belum termasuk dalam build awal."));
        space(body, 14);
        section(body, "Privasi & Keamanan", "", null);
        settingCard(body, "Privasi", "Audio dipilih melalui pemilih dokumen Android", "◇", () -> showInfo("Privasi", "Lucent hanya mengakses audio yang kamu pilih melalui pemilih dokumen sistem. Tidak ada akun atau pelacakan cloud pada versi ini."));
        settingCard(body, "Penyimpanan", songs.size() + " file audio tersimpan di pustaka", "▤", () -> showInfo("Penyimpanan", "Lucent menyimpan daftar URI dan metadata audio. File aslinya tetap berada di lokasi perangkatmu."));
        settingCard(body, "Cadangan dan pemulihan", "Ekspor daftar lagu", "⟳", () -> exportLibrary());
        space(body, 14);
        section(body, "Sistem & Tentang", "", null);
        settingCard(body, "Buka link yang didukung", "Pengaturan tautan aplikasi", "↗", () -> showInfo("Tautan", "Deep link khusus belum dikonfigurasi."));
        settingCard(body, "Tentang Lucent", "Versi 1.0.0 • Dark Purple Edition", "ⓘ", () -> showInfo("Lucent", "Lucent adalah pemutar musik lokal dengan antarmuka Dark Purple. Dibuat sebagai fondasi aplikasi yang dapat dikembangkan lebih lanjut."));
        return scroll(body);
    }

    private View nowPlayingPage() {
        LinearLayout body = pageColumn();
        LinearLayout top = row();
        TextView back = text("‹", 32, TEXT, true); back.setGravity(Gravity.CENTER);
        top.addView(back, new LinearLayout.LayoutParams(dp(42), dp(42)));
        back.setOnClickListener(v -> { page = "home"; renderPage(); });
        LinearLayout titleBox = column(); titleBox.setGravity(Gravity.CENTER);
        titleBox.addView(text("SEDANG DIPUTAR", 10, MUTED, true));
        top.addView(titleBox, new LinearLayout.LayoutParams(0, -2, 1));
        TextView more = text("•••", 19, MUTED, true); more.setGravity(Gravity.CENTER);
        top.addView(more, new LinearLayout.LayoutParams(dp(42), dp(42)));
        body.addView(top);
        if (currentIndex < 0 || currentIndex >= songs.size()) {
            body.addView(emptyText("Pilih lagu dari Pustaka untuk mulai memutar."));
            TextView add = action("＋  Tambahkan audio", true); body.addView(add); add.setOnClickListener(v -> pickAudio());
            return scroll(body);
        }
        Song s = songs.get(currentIndex);
        space(body, 28);
        TextView cover = artwork(250);
        cover.setTextSize(76);
        cover.setBackground(roundGradient(250));
        cover.setElevation(dp(10));
        LinearLayout.LayoutParams coverLp = new LinearLayout.LayoutParams(dp(250), dp(250));
        coverLp.gravity = Gravity.CENTER_HORIZONTAL;
        body.addView(cover, coverLp);
        space(body, 28);
        LinearLayout songInfo = row();
        LinearLayout labels = column();
        labels.addView(text(s.title, 20, TEXT, true));
        labels.addView(text(s.artist, 14, MUTED, false));
        songInfo.addView(labels, new LinearLayout.LayoutParams(0, -2, 1));
        TextView heart = text(liked.contains(s.key()) ? "♥" : "♡", 28, PURPLE, true); heart.setGravity(Gravity.CENTER);
        songInfo.addView(heart, new LinearLayout.LayoutParams(dp(42), dp(48)));
        heart.setOnClickListener(v -> { toggleLike(s); heart.setText(liked.contains(s.key()) ? "♥" : "♡"); });
        body.addView(songInfo);
        SeekBar seek = new SeekBar(this);
        seek.setMax(Math.max(1, duration > 0 ? duration : s.duration));
        seek.setProgress(Math.min(position, seek.getMax()));
        seek.setProgressTintList(android.content.res.ColorStateList.valueOf(PURPLE));
        seek.setThumbTintList(android.content.res.ColorStateList.valueOf(LAVENDER));
        body.addView(seek, new LinearLayout.LayoutParams(-1, dp(34)));
        LinearLayout times = row();
        times.addView(text(time(position), 11, MUTED, false), new LinearLayout.LayoutParams(0, -2, 1));
        TextView remaining = text("-" + time(Math.max(0, seek.getMax() - position)), 11, MUTED, false); remaining.setGravity(Gravity.RIGHT);
        times.addView(remaining, new LinearLayout.LayoutParams(0, -2, 1));
        body.addView(times);
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar b, int p, boolean user) { if (user) { position = p; remaining.setText("-" + time(Math.max(0, b.getMax() - p))); } }
            @Override public void onStartTrackingTouch(SeekBar b) { }
            @Override public void onStopTrackingTouch(SeekBar b) { Intent i = new Intent(MainActivity.this, PlaybackService.class).setAction(PlaybackService.ACTION_SEEK).putExtra(PlaybackService.EXTRA_SEEK, b.getProgress()); startService(i); }
        });
        space(body, 18);
        LinearLayout controls = row(); controls.setGravity(Gravity.CENTER);
        TextView shuffle = text("⤨", 22, shuffleEnabled ? PURPLE : MUTED, true); shuffle.setGravity(Gravity.CENTER);
        controls.addView(shuffle, new LinearLayout.LayoutParams(0, dp(54), 1));
        shuffle.setOnClickListener(v -> { shuffleEnabled = !shuffleEnabled; shuffle.setTextColor(shuffleEnabled ? PURPLE : MUTED); });
        TextView prev = text("|◀", 26, LAVENDER, true); prev.setGravity(Gravity.CENTER);
        controls.addView(prev, new LinearLayout.LayoutParams(0, dp(54), 1)); prev.setOnClickListener(v -> previousSong());
        TextView play = text(playing ? "Ⅱ" : "▶", 26, BG, true); play.setGravity(Gravity.CENTER); play.setBackground(round(PURPLE, 30, PURPLE, 1));
        controls.addView(play, new LinearLayout.LayoutParams(dp(62), dp(62))); play.setOnClickListener(v -> togglePlayback());
        TextView next = text("▶|", 26, LAVENDER, true); next.setGravity(Gravity.CENTER);
        controls.addView(next, new LinearLayout.LayoutParams(0, dp(54), 1)); next.setOnClickListener(v -> nextSong());
        TextView repeat = text("↻", 22, repeatOne ? PURPLE : MUTED, true); repeat.setGravity(Gravity.CENTER);
        controls.addView(repeat, new LinearLayout.LayoutParams(0, dp(54), 1));
        repeat.setOnClickListener(v -> { repeatOne = !repeatOne; repeat.setTextColor(repeatOne ? PURPLE : MUTED); });
        body.addView(controls);
        space(body, 18);
        LinearLayout lyrics = card(SURFACE);
        lyrics.addView(text("LIRIK", 11, PURPLE, true));
        lyrics.addView(text("Lirik belum tersedia untuk file ini.", 13, MUTED, false));
        body.addView(lyrics);
        space(body, 12);
        section(body, "Berikutnya di antrean", "", null);
        for (int n = 1; n <= Math.min(3, Math.max(0, songs.size() - 1)); n++) addSongRow(body, (currentIndex + n) % songs.size(), false);
        return scroll(body);
    }

    private void addTopBar(LinearLayout body, String title, boolean showSettings) {
        LinearLayout bar = row();
        TextView brand = text(title, 26, TEXT, true);
        brand.setTypeface(Typeface.SERIF, Typeface.BOLD);
        bar.addView(brand, new LinearLayout.LayoutParams(0, dp(48), 1));
        if (showSettings) {
            TextView history = text("◷", 21, MUTED, true); history.setGravity(Gravity.CENTER);
            bar.addView(history, new LinearLayout.LayoutParams(dp(38), dp(44)));
            history.setOnClickListener(v -> { page = "library"; libraryTab = "Lagu"; renderPage(); });
            TextView stats = text("⌁", 21, MUTED, true); stats.setGravity(Gravity.CENTER);
            bar.addView(stats, new LinearLayout.LayoutParams(dp(38), dp(44)));
            stats.setOnClickListener(v -> showInfo("Aktivitas", "Statistik mendengarkan akan dikembangkan pada versi berikutnya."));
            TextView setting = text("⚙", 21, MUTED, true); setting.setGravity(Gravity.CENTER);
            bar.addView(setting, new LinearLayout.LayoutParams(dp(38), dp(44)));
            setting.setOnClickListener(v -> { page = "settings"; renderPage(); });
        }
        body.addView(bar);
        space(body, 12);
    }

    private void addSongRow(LinearLayout parent, int index, boolean showLike) {
        if (index < 0 || index >= songs.size()) return;
        Song s = songs.get(index);
        LinearLayout item = row();
        item.setGravity(Gravity.CENTER_VERTICAL);
        item.setPadding(dp(7), dp(7), dp(7), dp(7));
        item.addView(artwork(48), new LinearLayout.LayoutParams(dp(48), dp(48)));
        LinearLayout labels = column(); labels.setGravity(Gravity.CENTER_VERTICAL); labels.setPadding(dp(11), 0, dp(5), 0);
        TextView name = text(s.title, 14, TEXT, true); name.setMaxLines(1);
        labels.addView(name);
        TextView artist = text(s.artist, 12, MUTED, false); artist.setMaxLines(1);
        labels.addView(artist);
        item.addView(labels, new LinearLayout.LayoutParams(0, -2, 1));
        if (showLike) {
            TextView heart = text(liked.contains(s.key()) ? "♥" : "♡", 21, liked.contains(s.key()) ? PURPLE : MUTED, true);
            heart.setGravity(Gravity.CENTER);
            item.addView(heart, new LinearLayout.LayoutParams(dp(36), dp(46)));
            heart.setOnClickListener(v -> toggleLike(s));
        }
        TextView play = text("⋯", 20, MUTED, true); play.setGravity(Gravity.CENTER);
        item.addView(play, new LinearLayout.LayoutParams(dp(32), dp(46)));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(64)); lp.setMargins(0, 0, 0, dp(4));
        parent.addView(item, lp);
        item.setOnClickListener(v -> playSong(index));
        play.setOnClickListener(v -> showSongMenu(index));
    }

    private void settingCard(LinearLayout parent, String title, String subtitle, String icon, Runnable click) {
        LinearLayout item = row(); item.setGravity(Gravity.CENTER_VERTICAL); item.setPadding(dp(12), dp(10), dp(12), dp(10)); item.setBackground(round(SURFACE, 14, LINE, 1));
        TextView ico = text(icon, 21, PURPLE, true); ico.setGravity(Gravity.CENTER);
        item.addView(ico, new LinearLayout.LayoutParams(dp(40), dp(48)));
        LinearLayout info = column(); info.setPadding(dp(7), 0, dp(4), 0);
        info.addView(text(title, 14, TEXT, true)); info.addView(text(subtitle, 12, MUTED, false));
        item.addView(info, new LinearLayout.LayoutParams(0, -2, 1));
        item.addView(text("›", 24, MUTED, false));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2); lp.setMargins(0, 0, 0, dp(6)); parent.addView(item, lp);
        item.setOnClickListener(v -> click.run());
    }

    private void settingToggle(LinearLayout parent, String title, String subtitle, boolean checked) {
        LinearLayout item = row(); item.setGravity(Gravity.CENTER_VERTICAL); item.setPadding(dp(12), dp(10), dp(12), dp(10)); item.setBackground(round(SURFACE, 14, LINE, 1));
        LinearLayout info = column(); info.addView(text(title, 14, TEXT, true)); info.addView(text(subtitle, 12, MUTED, false));
        item.addView(info, new LinearLayout.LayoutParams(0, -2, 1));
        TextView toggle = text(checked ? "●" : "○", 23, checked ? PURPLE : MUTED, true); toggle.setGravity(Gravity.CENTER);
        item.addView(toggle, new LinearLayout.LayoutParams(dp(42), dp(40)));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2); lp.setMargins(0, 0, 0, dp(6)); parent.addView(item, lp);
        final boolean[] value = {checked};
        View.OnClickListener listener = v -> { value[0] = !value[0]; toggle.setText(value[0] ? "●" : "○"); toggle.setTextColor(value[0] ? PURPLE : MUTED); };
        item.setOnClickListener(listener); toggle.setOnClickListener(listener);
    }

    private void section(LinearLayout parent, String title, String action, Runnable callback) {
        LinearLayout r = row(); r.setGravity(Gravity.CENTER_VERTICAL);
        TextView t = text(title, 18, TEXT, true); t.setTypeface(Typeface.SERIF, Typeface.BOLD);
        r.addView(t, new LinearLayout.LayoutParams(0, dp(38), 1));
        if (action != null && !action.isEmpty()) {
            TextView a = text(action, 10, PURPLE, true); r.addView(a);
            if (callback != null) a.setOnClickListener(v -> callback.run());
        }
        parent.addView(r);
        space(parent, 5);
    }

    private LinearLayout pageColumn() {
        LinearLayout c = column(); c.setPadding(dp(16), dp(8), dp(16), dp(22)); return c;
    }
    private LinearLayout column() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l; }
    private LinearLayout row() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL); return l; }
    private LinearLayout card(int color) { LinearLayout l = column(); l.setPadding(dp(14), dp(14), dp(14), dp(14)); l.setBackground(round(color, 18, LINE, 1)); return l; }
    private ScrollView scroll(View content) { ScrollView s = new ScrollView(this); s.setFillViewport(false); s.setClipToPadding(false); s.addView(content); return s; }
    private TextView text(String value, int size, int color, boolean bold) { TextView t = new TextView(this); t.setText(value); t.setTextSize(size); t.setTextColor(color); t.setTypeface(Typeface.DEFAULT, bold ? Typeface.BOLD : Typeface.NORMAL); t.setGravity(Gravity.CENTER_VERTICAL); return t; }
    private TextView action(String label, boolean primary) { TextView t = text(label, 14, primary ? BG : LAVENDER, true); t.setGravity(Gravity.CENTER); t.setBackground(round(primary ? PURPLE : SURFACE_2, 14, primary ? PURPLE : LINE, 1)); return t; }
    private TextView emptyText(String value) { TextView t = text(value, 13, MUTED, false); t.setPadding(dp(15), dp(18), dp(15), dp(18)); t.setBackground(round(SURFACE, 14, LINE, 1)); return t; }
    private TextView artwork(int size) { TextView t = text("♫", size > 100 ? 60 : 23, LAVENDER, true); t.setGravity(Gravity.CENTER); t.setBackground(roundGradient(size)); return t; }
    private GradientDrawable round(int color, int radius, int stroke, int strokeWidth) { GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); if (strokeWidth > 0) d.setStroke(dp(strokeWidth), stroke); return d; }
    private GradientDrawable roundGradient(int radius) { GradientDrawable d = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{Color.rgb(89, 58, 130), Color.rgb(42, 28, 66), Color.rgb(27, 20, 42)}); d.setCornerRadius(dp(Math.max(12, radius / 8))); d.setStroke(dp(1), LINE); return d; }
    private void space(LinearLayout p, int h) { View v = new View(this); p.addView(v, new LinearLayout.LayoutParams(1, dp(h))); }
    private int dp(float n) { return (int) (n * getResources().getDisplayMetrics().density + 0.5f); }
    private String time(int ms) { int sec = Math.max(0, ms / 1000); return String.format(Locale.getDefault(), "%d:%02d", sec / 60, sec % 60); }

    private void pickAudio() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("audio/*");
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        try { startActivityForResult(i, PICK_AUDIO); }
        catch (Exception e) { Toast.makeText(this, "Pemilih file tidak tersedia", Toast.LENGTH_SHORT).show(); }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != PICK_AUDIO || resultCode != RESULT_OK || data == null) return;
        int flags = data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        try {
            if (data.getData() != null) getContentResolver().takePersistableUriPermission(data.getData(), flags);
            if (data.getClipData() != null) {
                ClipData clip = data.getClipData();
                for (int i = 0; i < clip.getItemCount(); i++) {
                    Uri uri = clip.getItemAt(i).getUri();
                    try { getContentResolver().takePersistableUriPermission(uri, flags); } catch (Exception ignored) { }
                    addSong(uri);
                }
            } else if (data.getData() != null) addSong(data.getData());
            saveSongs();
            Toast.makeText(this, "Audio ditambahkan ke Lucent", Toast.LENGTH_SHORT).show();
            renderPage();
        } catch (Exception e) { Toast.makeText(this, "Gagal membaca file audio", Toast.LENGTH_SHORT).show(); }
    }

    private void addSong(Uri uri) {
        for (Song s : songs) if (s.uri.equals(uri.toString())) return;
        Song song = readMetadata(uri);
        songs.add(song);
        if (currentIndex < 0) currentIndex = 0;
    }

    private Song readMetadata(Uri uri) {
        String title = queryDisplayName(uri);
        String artist = "Audio lokal";
        int duration = 0;
        String album = "Album tidak diketahui";
        MediaMetadataRetriever mmr = new MediaMetadataRetriever();
        try {
            mmr.setDataSource(this, uri);
            String t = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE);
            String a = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST);
            String al = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUM);
            String d = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
            if (t != null && !t.trim().isEmpty()) title = t;
            if (a != null && !a.trim().isEmpty()) artist = a;
            if (al != null && !al.trim().isEmpty()) album = al;
            if (d != null) duration = (int) Math.min(Integer.MAX_VALUE, Long.parseLong(d));
        } catch (Exception ignored) { }
        finally { try { mmr.release(); } catch (Exception ignored) { } }
        return new Song(uri.toString(), title, artist, album, duration);
    }

    private String queryDisplayName(Uri uri) {
        String name = null;
        try (android.database.Cursor c = getContentResolver().query(uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
            if (c != null && c.moveToFirst()) name = c.getString(0);
        } catch (Exception ignored) { }
        if (name == null) name = "Audio tanpa judul";
        int dot = name.lastIndexOf('.');
        if (dot > 0) name = name.substring(0, dot);
        return name;
    }

    private void loadSaved() {
        try {
            JSONArray arr = new JSONArray(prefs.getString("songs", "[]"));
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                Uri uri = Uri.parse(o.getString("uri"));
                songs.add(readMetadata(uri));
            }
        } catch (Exception ignored) { }
        try {
            JSONArray arr = new JSONArray(prefs.getString("playlists", "[]"));
            for (int i = 0; i < arr.length(); i++) {
                JSONObject entry = arr.getJSONObject(i);
                String name = entry.getString("name"); playlists.add(name);
                Set<String> members = new HashSet<>(); JSONArray tracks = entry.optJSONArray("tracks");
                if (tracks != null) for (int j = 0; j < tracks.length(); j++) members.add(tracks.getString(j));
                playlistTracks.put(name, members);
            }
        } catch (Exception ignored) { }
        liked.addAll(prefs.getStringSet("liked", new HashSet<>()));
        if (!songs.isEmpty()) currentIndex = prefs.getInt("current", 0);
        if (currentIndex >= songs.size()) currentIndex = songs.size() - 1;
    }

    private void saveSongs() {
        JSONArray arr = new JSONArray();
        try { for (Song s : songs) { JSONObject o = new JSONObject(); o.put("uri", s.uri); arr.put(o); } } catch (Exception ignored) { }
        prefs.edit().putString("songs", arr.toString()).putInt("current", currentIndex).apply();
    }

    private void savePlaylists() {
        JSONArray arr = new JSONArray();
        try {
            for (String p : playlists) {
                JSONObject entry = new JSONObject(); entry.put("name", p);
                JSONArray tracks = new JSONArray();
                for (String uri : playlistTracks.getOrDefault(p, new HashSet<>())) tracks.put(uri);
                entry.put("tracks", tracks); arr.put(entry);
            }
        } catch (Exception ignored) { }
        prefs.edit().putString("playlists", arr.toString()).apply();
    }

    private void toggleLike(Song song) {
        if (liked.contains(song.key())) liked.remove(song.key()); else liked.add(song.key());
        prefs.edit().putStringSet("liked", new HashSet<>(liked)).apply();
        renderPage();
    }

    private void playSong(int index) {
        if (index < 0 || index >= songs.size()) return;
        currentIndex = index;
        Song s = songs.get(index);
        Intent i = new Intent(this, PlaybackService.class).setAction(PlaybackService.ACTION_LOAD)
                .putExtra(PlaybackService.EXTRA_URI, s.uri)
                .putExtra(PlaybackService.EXTRA_TITLE, s.title)
                .putExtra(PlaybackService.EXTRA_ARTIST, s.artist);
        startPlaybackService(i);
        prefs.edit().putInt("current", currentIndex).apply();
        playing = true; serviceHasTrack = true; position = 0; duration = s.duration;
        refreshPlayerChrome();
    }

    private void startPlaybackService(Intent i) {
        try {
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
        } catch (Exception e) { Toast.makeText(this, "Tidak dapat memulai pemutar audio", Toast.LENGTH_SHORT).show(); }
    }

    private void togglePlayback() {
        if (currentIndex < 0 || currentIndex >= songs.size()) { pickAudio(); return; }
        if (!serviceHasTrack) { playSong(currentIndex); return; }
        Intent i = new Intent(this, PlaybackService.class).setAction(playing ? PlaybackService.ACTION_PAUSE : PlaybackService.ACTION_PLAY);
        startPlaybackService(i);
        playing = !playing;
        refreshPlayerChrome();
    }

    private void nextSong() {
        if (songs.isEmpty()) return;
        int next;
        if (repeatOne && currentIndex >= 0) next = currentIndex;
        else if (shuffleEnabled && songs.size() > 1) { do { next = new Random().nextInt(songs.size()); } while (next == currentIndex); }
        else next = currentIndex < 0 ? 0 : (currentIndex + 1) % songs.size();
        playSong(next);
    }

    private void previousSong() {
        if (songs.isEmpty()) return;
        if (position > 4000) {
            Intent i = new Intent(this, PlaybackService.class).setAction(PlaybackService.ACTION_SEEK).putExtra(PlaybackService.EXTRA_SEEK, 0);
            startService(i); position = 0; refreshPlayerChrome();
        } else {
            int prev = currentIndex <= 0 ? songs.size() - 1 : currentIndex - 1;
            playSong(prev);
        }
    }

    private void refreshPlayerChrome() {
        if (root != null) {
            rebuildBottomChrome();
            if ("now".equals(page)) renderPage();
        }
    }

    private void createPlaylist() {
        EditText input = new EditText(this); input.setHint("Nama playlist"); input.setTextColor(TEXT); input.setHintTextColor(MUTED);
        new AlertDialog.Builder(this).setTitle("Playlist baru").setView(input)
                .setNegativeButton("Batal", null)
                .setPositiveButton("Buat", (d, w) -> {
                    String name = input.getText().toString().trim();
                    if (!name.isEmpty() && !playlists.contains(name)) { playlists.add(name); playlistTracks.put(name, new HashSet<>()); savePlaylists(); renderPage(); }
                }).show();
    }


    private View dynamicIslandPreview() {
        LinearLayout preview = card(Color.rgb(23, 17, 36));
        preview.addView(text("PRATINJAU • DI DALAM APLIKASI", 10, MUTED, true));
        LinearLayout capsule = row();
        capsule.setGravity(Gravity.CENTER_VERTICAL);
        capsule.setPadding(dp(13), dp(10), dp(13), dp(10));
        capsule.setBackground(round(Color.rgb(43, 28, 65), 24, Color.rgb(103, 72, 143), 1));
        TextView dot = text("♫", 18, LAVENDER, true); dot.setGravity(Gravity.CENTER);
        capsule.addView(dot, new LinearLayout.LayoutParams(dp(32), dp(32)));
        LinearLayout info = column(); info.setPadding(dp(8), 0, 0, 0);
        String song = currentIndex >= 0 && currentIndex < songs.size() ? songs.get(currentIndex).title : "Belum ada lagu";
        info.addView(text(song, 12, TEXT, true));
        info.addView(text("Lucent • Now Playing", 10, MUTED, false));
        capsule.addView(info, new LinearLayout.LayoutParams(0, -2, 1));
        capsule.addView(text(playing ? "Ⅱ" : "⌁", 18, LAVENDER, true));
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2); cp.topMargin = dp(10);
        preview.addView(capsule, cp);
        preview.addView(text("Kapsul ini hanya pratinjau di Lucent; overlay di atas aplikasi lain belum diaktifkan.", 11, MUTED, false));
        return preview;
    }

    private void showPresetDialog() {
        String[] presets = {"iPhone", "Kaca", "Berwarna", "Minimalis"};
        new AlertDialog.Builder(this).setTitle("Pilih preset tampilan")
                .setSingleChoiceItems(presets, java.util.Arrays.asList(presets).indexOf(prefs.getString("preset", "Minimalis")), (dialog, which) -> {
                    prefs.edit().putString("preset", presets[which]).apply();
                    dialog.dismiss(); renderPage();
                }).setNegativeButton("Batal", null).show();
    }

    private void showThemeInfo() {
        new AlertDialog.Builder(this).setTitle("Tema Lucent • Dark Purple")
                .setMessage("Latar: ungu kehitaman\nKartu: deep purple\nAksen: violet dan lavender\nTeks: putih lembut\n\nPreset iPhone, Kaca, Berwarna, dan Minimalis tersedia sebagai pilihan gaya pada menu Preset tampilan.")
                .setPositiveButton("Mengerti", null).show();
    }

    private void showInfo(String title, String message) {
        new AlertDialog.Builder(this).setTitle(title).setMessage(message).setPositiveButton("Tutup", null).show();
    }

    private void exportLibrary() {
        StringBuilder b = new StringBuilder("Lucent Library\n\n");
        for (Song s : songs) b.append(s.title).append(" — ").append(s.artist).append("\n");
        Intent share = new Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, b.toString());
        try { startActivity(Intent.createChooser(share, "Ekspor daftar lagu")); }
        catch (Exception e) { Toast.makeText(this, "Tidak dapat mengekspor daftar", Toast.LENGTH_SHORT).show(); }
    }
}

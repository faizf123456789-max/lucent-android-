package com.lucent.music;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.AudioFocusRequest;
import android.media.MediaPlayer;
import android.media.MediaMetadata;
import android.media.session.MediaSession;
import android.media.session.PlaybackState;
import android.net.Uri;
import android.os.Build;
import android.os.IBinder;
import android.os.SystemClock;
import android.os.Handler;
import android.os.Looper;

public class PlaybackService extends Service {
    public static final String ACTION_LOAD = "com.lucent.music.LOAD";
    public static final String ACTION_PLAY = "com.lucent.music.PLAY";
    public static final String ACTION_PAUSE = "com.lucent.music.PAUSE";
    public static final String ACTION_STOP = "com.lucent.music.STOP";
    public static final String ACTION_SEEK = "com.lucent.music.SEEK";
    public static final String EXTRA_SEEK = "seek";
    public static final String ACTION_NEXT_REQUEST = "com.lucent.music.NEXT_REQUEST";
    public static final String ACTION_PREV_REQUEST = "com.lucent.music.PREV_REQUEST";
    public static final String ACTION_STATE = "com.lucent.music.PLAYER_STATE";
    public static final String EXTRA_URI = "uri";
    public static final String EXTRA_TITLE = "title";
    public static final String EXTRA_ARTIST = "artist";
    public static final String EXTRA_PLAYING = "playing";
    public static final String EXTRA_DURATION = "duration";
    public static final String EXTRA_POSITION = "position";
    public static final String EXTRA_READY = "ready";

    private static final String CHANNEL_ID = "lucent_playback";
    private static final int NOTIFICATION_ID = 71;
    private MediaPlayer player;
    private MediaSession mediaSession;
    private String title = "Belum ada lagu";
    private String artist = "Pilih audio dari perangkat";
    private boolean preparing = false;
    private AudioManager audioManager;
    private AudioFocusRequest focusRequest;
    private final AudioManager.OnAudioFocusChangeListener focusListener = change -> {
        if (change == AudioManager.AUDIOFOCUS_LOSS || change == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT) pause();
    };
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable ticker = new Runnable() { @Override public void run() { if (player != null) { publishState(); handler.postDelayed(this, 1000); } } };

    @Override public void onCreate() {
        super.onCreate();
        audioManager = (AudioManager) getSystemService(AUDIO_SERVICE);
        createChannel();
        mediaSession = new MediaSession(this, "LucentSession");
        mediaSession.setFlags(MediaSession.FLAG_HANDLES_MEDIA_BUTTONS | MediaSession.FLAG_HANDLES_TRANSPORT_CONTROLS);
        mediaSession.setCallback(new MediaSession.Callback() {
            @Override public void onPlay() { play(); }
            @Override public void onPause() { pause(); }
            @Override public void onStop() { stopPlayback(); }
            @Override public void onSkipToNext() { sendPlayerCommand(ACTION_NEXT_REQUEST); }
            @Override public void onSkipToPrevious() { sendPlayerCommand(ACTION_PREV_REQUEST); }
            @Override public void onSeekTo(long pos) {
                if (player != null && !preparing) {
                    try { player.seekTo((int) pos); publishState(); } catch (IllegalStateException ignored) { }
                }
            }
        });
        mediaSession.setActive(true);
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) return START_NOT_STICKY;
        String action = intent.getAction();
        if (ACTION_LOAD.equals(action)) {
            String raw = intent.getStringExtra(EXTRA_URI);
            title = safe(intent.getStringExtra(EXTRA_TITLE), "Audio lokal");
            artist = safe(intent.getStringExtra(EXTRA_ARTIST), "Perangkat ini");
            if (raw != null) load(Uri.parse(raw));
        } else if (ACTION_PLAY.equals(action)) {
            play();
        } else if (ACTION_PAUSE.equals(action)) {
            pause();
        } else if (ACTION_STOP.equals(action)) {
            stopPlayback();
        } else if (ACTION_NEXT_REQUEST.equals(action) || ACTION_PREV_REQUEST.equals(action)) {
            sendPlayerCommand(action);
        } else if (ACTION_SEEK.equals(action)) {
            if (player != null && !preparing) { try { player.seekTo(intent.getIntExtra(EXTRA_SEEK, 0)); publishState(); } catch (Exception ignored) { } }
        }
        return START_STICKY;
    }

    private String safe(String value, String fallback) {
        return value == null || value.trim().isEmpty() ? fallback : value;
    }

    private void load(Uri uri) {
        releasePlayer();
        preparing = true;
        try {
            requestAudioFocus();
            player = new MediaPlayer();
            player.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build());
            player.setDataSource(this, uri);
            player.setOnPreparedListener(mp -> {
                preparing = false;
                mp.start();
                updateSession();
                publishState();
                updateNotification();
            });
            player.setOnCompletionListener(mp -> {
                publishState();
                sendPlayerCommand(ACTION_NEXT_REQUEST);
            });
            player.setOnErrorListener((mp, what, extra) -> {
                preparing = false;
                publishState();
                return true;
            });
            startForeground(NOTIFICATION_ID, buildNotification());
            player.prepareAsync();
            handler.removeCallbacks(ticker); handler.postDelayed(ticker, 1000);
            updateSession();
            publishState();
        } catch (Exception e) {
            preparing = false;
            releasePlayer();
            publishState();
            if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_REMOVE); else stopForeground(true);
        }
    }

    private void play() {
        requestAudioFocus();
        if (player != null && !preparing) {
            try {
                if (!player.isPlaying()) player.start();
                updateSession(); publishState(); updateNotification();
            } catch (IllegalStateException ignored) { }
        }
    }

    private void pause() {
        if (player != null && !preparing) {
            try {
                if (player.isPlaying()) player.pause();
                updateSession(); publishState(); updateNotification();
            } catch (IllegalStateException ignored) { }
        }
    }

    private void stopPlayback() {
        releasePlayer();
        abandonAudioFocus();
        handler.removeCallbacks(ticker);
        preparing = false;
        publishState();
        if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_REMOVE); else stopForeground(true);
        stopSelf();
    }

    private void requestAudioFocus() {
        if (audioManager == null) return;
        if (Build.VERSION.SDK_INT >= 26) {
            if (focusRequest == null) {
                focusRequest = new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                        .setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
                        .setOnAudioFocusChangeListener(focusListener).build();
            }
            audioManager.requestAudioFocus(focusRequest);
        } else {
            audioManager.requestAudioFocus(focusListener, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN);
        }
    }

    private void abandonAudioFocus() {
        if (audioManager == null) return;
        if (Build.VERSION.SDK_INT >= 26 && focusRequest != null) audioManager.abandonAudioFocusRequest(focusRequest);
        else audioManager.abandonAudioFocus(focusListener);
    }

    private void releasePlayer() {
        if (player != null) {
            try { player.reset(); } catch (Exception ignored) { }
            try { player.release(); } catch (Exception ignored) { }
            player = null;
        }
    }

    private void sendPlayerCommand(String action) {
        Intent i = new Intent(action);
        i.setPackage(getPackageName());
        sendBroadcast(i);
    }

    private void publishState() {
        boolean playing = false;
        int duration = 0, position = 0;
        if (player != null && !preparing) {
            try {
                playing = player.isPlaying();
                duration = player.getDuration();
                position = player.getCurrentPosition();
            } catch (IllegalStateException ignored) { }
        }
        Intent i = new Intent(ACTION_STATE);
        i.setPackage(getPackageName());
        i.putExtra(EXTRA_TITLE, title);
        i.putExtra(EXTRA_ARTIST, artist);
        i.putExtra(EXTRA_PLAYING, playing);
        i.putExtra(EXTRA_DURATION, duration);
        i.putExtra(EXTRA_POSITION, position);
        i.putExtra(EXTRA_READY, player != null && !preparing);
        sendBroadcast(i);
        updateSession();
    }

    private void updateSession() {
        if (mediaSession == null) return;
        boolean playing = false;
        long position = 0;
        if (player != null && !preparing) {
            try { playing = player.isPlaying(); position = player.getCurrentPosition(); } catch (Exception ignored) { }
        }
        mediaSession.setMetadata(new MediaMetadata.Builder()
                .putString(MediaMetadata.METADATA_KEY_TITLE, title)
                .putString(MediaMetadata.METADATA_KEY_ARTIST, artist)
                .build());
        long actions = PlaybackState.ACTION_PLAY | PlaybackState.ACTION_PAUSE | PlaybackState.ACTION_PLAY_PAUSE
                | PlaybackState.ACTION_SKIP_TO_NEXT | PlaybackState.ACTION_SKIP_TO_PREVIOUS
                | PlaybackState.ACTION_SEEK_TO | PlaybackState.ACTION_STOP;
        mediaSession.setPlaybackState(new PlaybackState.Builder()
                .setActions(actions)
                .setState(playing ? PlaybackState.STATE_PLAYING : PlaybackState.STATE_PAUSED,
                        position, playing ? 1f : 0f, SystemClock.elapsedRealtime())
                .build());
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "Pemutaran Lucent", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Kontrol pemutar musik Lucent");
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(channel);
        }
    }

    private Notification buildNotification() {
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent content = PendingIntent.getActivity(this, 1, open,
                PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));
        Intent pauseIntent = new Intent(this, PlaybackService.class).setAction(ACTION_PAUSE);
        Intent playIntent = new Intent(this, PlaybackService.class).setAction(ACTION_PLAY);
        Intent prevIntent = new Intent(this, PlaybackService.class).setAction(ACTION_PREV_REQUEST);
        Intent nextIntent = new Intent(this, PlaybackService.class).setAction(ACTION_NEXT_REQUEST);
        int immutable = Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0;
        PendingIntent toggle = PendingIntent.getService(this, 2, isPlaying() ? pauseIntent : playIntent, PendingIntent.FLAG_UPDATE_CURRENT | immutable);
        PendingIntent prev = PendingIntent.getService(this, 3, prevIntent, PendingIntent.FLAG_UPDATE_CURRENT | immutable);
        PendingIntent next = PendingIntent.getService(this, 4, nextIntent, PendingIntent.FLAG_UPDATE_CURRENT | immutable);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL_ID) : new Notification.Builder(this);
        b.setSmallIcon(android.R.drawable.ic_media_play)
                .setContentTitle(title).setContentText(artist)
                .setContentIntent(content).setOngoing(isPlaying()).setOnlyAlertOnce(true)
                .addAction(new Notification.Action.Builder(android.R.drawable.ic_media_previous, "Sebelumnya", prev).build())
                .addAction(new Notification.Action.Builder(isPlaying() ? android.R.drawable.ic_media_pause : android.R.drawable.ic_media_play,
                        isPlaying() ? "Jeda" : "Putar", toggle).build())
                .addAction(new Notification.Action.Builder(android.R.drawable.ic_media_next, "Berikutnya", next).build());
        if (Build.VERSION.SDK_INT >= 21) b.setStyle(new Notification.MediaStyle().setMediaSession(mediaSession.getSessionToken()).setShowActionsInCompactView(0, 1, 2));
        return b.build();
    }

    private boolean isPlaying() {
        try { return player != null && !preparing && player.isPlaying(); }
        catch (Exception e) { return false; }
    }

    private void updateNotification() {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (nm != null && player != null) nm.notify(NOTIFICATION_ID, buildNotification());
    }

    @Override public IBinder onBind(Intent intent) { return null; }

    @Override public void onDestroy() {
        releasePlayer();
        handler.removeCallbacks(ticker);
        if (mediaSession != null) { mediaSession.setActive(false); mediaSession.release(); }
        super.onDestroy();
    }
}

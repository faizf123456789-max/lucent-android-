# Lucent — Dark Purple Edition

Android starter project for **Lucent**, a local-first music player inspired by the six supplied UI references. The visual identity is deep purple with lavender/violet accents; no orange accent color is used.

## What's implemented

- Dark Purple visual system, editorial section headings, rounded cards and bottom navigation (Beranda / Cari / Pustaka).
- Home screen with recently added tracks, listening-streak card, mood chips and Speed dial shortcuts.
- Search across locally imported audio title/artist metadata.
- Library tabs for Playlist, Lagu, Album, Artis, Podcast, Disukai, Diunduh and Diunggah.
- Import one or multiple audio files through Android's system document picker (`ACTION_OPEN_DOCUMENT`). No broad storage permission is requested.
- Read local title, artist and duration metadata; persist selected document URIs and favorites.
- Playback using Android `MediaPlayer` in a foreground media-playback service, with a media session and notification controls.
- Mini-player, Now Playing screen, seek bar, previous/next, play/pause and favorite controls.
- Create named playlists, add/remove tracks in playlists, favorite tracks, export a text list of the local library, and settings screens.
- Dark Purple preset selector (iPhone / Kaca / Berwarna / Minimalis) and an in-app Dynamic Island-style preview.

## Not implemented / limitations

This is a first source-project milestone, **not a verified release APK**. The current environment has Java 21 but no Android SDK, Android build-tools, or Gradle installation, so an APK could not be built or tested here.

The following are placeholders or partial UI only:

- Album, artist and podcast browsing is not yet grouped into real collection views.
- Download/offline-cache and cloud upload are not implemented; the app plays user-selected local files.
- Lyrics and AI translation need a licensed lyrics provider and backend; no service is configured.
- Android Auto integration is not included.
- Dynamic Island is an in-app preview only. No system-wide overlay permission is requested.
- Theme presets are saved as a preference; the primary Dark Purple palette remains the active visual palette.
- Streak, high-refresh-rate, landscape scaling and several settings rows are UI preferences/placeholders rather than device-level implementations.
- Playback queue follows the imported local library order; shuffle and repeat-one are available from Now Playing but are session-only.

No copyrighted tracks or artwork from the reference screenshots are bundled. Users choose their own audio files.

## Build an APK locally

1. Install **Android Studio** (current stable) and Android SDK Platform 35, Build Tools 35.x, and JDK 17.
2. Open this `lucent-android` folder in Android Studio.
3. Allow Gradle sync. The project uses Android Gradle Plugin 8.7.3 and Gradle 8.9.
4. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. The debug APK should appear at `app/build/outputs/apk/debug/app-debug.apk`.

Or, after installing Gradle 8.9 and configuring `ANDROID_HOME` with SDK 35:

```bash
gradle :app:assembleDebug
```

The project intentionally has no third-party runtime dependencies.

## Package

- Application ID: `com.lucent.music`
- Version: `1.0.0` (versionCode 1)
- Minimum Android: API 23 (Android 6.0)
- Target / compile SDK: 35
- Language: Java 17

## Build APK with GitHub Actions

A workflow is included at `.github/workflows/android.yml`. Push this project to a GitHub repository on the `main` or `master` branch, or run **Actions → Build Lucent APK → Run workflow**. When the job succeeds, open its run page and download the `lucent-debug-apk` artifact. The workflow installs JDK 17, Android SDK Platform 35 / Build Tools 35.0.0 and Gradle 8.9, then runs `:app:assembleDebug`.

## Latest development update

- Album and artist tabs now group imported local audio using embedded metadata (album and artist names).
- Search now also matches album metadata.
- Album/artist groups open a list of their tracks.
- Added a GitHub Actions workflow to build and publish the debug APK as a downloadable workflow artifact.

The workflow has been authored but has **not** been executed from this environment. A successful APK build and on-device playback test are still required before calling this a verified release.
